function addProduct() {

    const productList = document.getElementById('productList');

    const productDiv = document.createElement('div');

    productDiv.innerHTML = `

        <h3>اسم المنتج: <span id="productName"></span></h3>

        <p>السعر: <span id="productPrice"></span></p>

    `;

    productList.appendChild(productDiv);

}

function shareLink() {

    const url = window.location.href;

    navigator.clipboard.writeText(url).then(() => {

        alert('تم نسخ الرابط للمشاركة: ' + url);

    });

}